package com.lqm.common.constants;

public interface CommonConstants {
    String UTF8 = "UTF-8";
    Integer SUCCESS = 1;
    Integer FAIL = 0;
    Integer STATUS_ERROR = 0;
    Integer STATUS_NORMAL = 1;
    String IMAGE_CODE_TYPE = "blockPuzzle";
    Long MENU_TREE_ROOT_ID = -1L;
    Long CATEGORY_TREE_ROOT_ID = -1L;
    String OK = "OK";
    String NO = "NO";
    String ORDER_INDICATOR = "orderIndicator";
}
