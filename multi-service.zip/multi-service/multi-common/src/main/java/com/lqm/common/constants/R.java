package com.lqm.common.constants;

import java.io.Serializable;

public class R<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    private int code;

    private String msg;

    private Boolean success;

    private T data;

    public boolean success() {
        return CommonConstants.SUCCESS == this.code ? Boolean.TRUE : Boolean.FALSE;
    }

    private static <T> R<T> restResult(T data, int code, String msg, Boolean success) {
        R<T> apiResult = new R();
        apiResult.setCode(code);
        apiResult.setData(data);
        apiResult.setMsg(msg);
        apiResult.setSuccess(success);
        return apiResult;
    }

    public String toString() {
        return "R(code=" + this.getCode() + ", msg=" + this.getMsg() + ", success=" + this.getSuccess() + ", data=" + this.getData() + ")";
    }

    public R() {
    }

    public R(int code, String msg, Boolean success, T data) {
        this.code = code;
        this.msg = msg;
        this.success = success;
        this.data = data;
    }

    public int getCode() {
        return this.code;
    }

    public R<T> setCode(int code) {
        this.code = code;
        return this;
    }

    public String getMsg() {
        return this.msg;
    }

    public R<T> setMsg(String msg) {
        this.msg = msg;
        return this;
    }

    public Boolean getSuccess() {
        return this.success;
    }

    public R<T> setSuccess(Boolean success) {
        this.success = success;
        return this;
    }

    public T getData() {
        return this.data;
    }

    public R<T> setData(T data) {
        this.data = data;
        return this;
    }

    public static <T> R<T> ok(T data) {
        return new R(0, "成功", true, data);
    }
}
