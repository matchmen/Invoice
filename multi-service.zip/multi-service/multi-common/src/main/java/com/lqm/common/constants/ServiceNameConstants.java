package com.lqm.common.constants;

public class ServiceNameConstants {

    public final static String USER_SERVICE = "multi-user-service";

    public final static String SHOP_SERVICE = "multi-shop-service";

    public final static String ORDER_SERVICE = "multi-order-service";

}
