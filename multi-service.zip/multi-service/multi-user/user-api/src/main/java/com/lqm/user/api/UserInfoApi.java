package com.lqm.user.api;

import com.lqm.common.constants.R;
import com.lqm.common.constants.ServiceNameConstants;
import com.lqm.user.dto.UserDto;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(contextId = "userInfoApi",value = ServiceNameConstants.USER_SERVICE)
public interface UserInfoApi {

    R<UserDto> getUserById(Long userId);

}
