package com.lqm.user.controller;

import com.lqm.common.constants.R;
import com.lqm.user.dto.UserDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController{

    @GetMapping("user")
    public R<UserDto> getUserById(Long userId) {
        UserDto userDto = new UserDto();
        userDto.setId(111L);
        userDto.setName("张三");
        return R.ok(userDto);
    }
}
